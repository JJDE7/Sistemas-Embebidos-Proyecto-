#include "ExpMorse.h"
#include <Arduino.h>

    String AlfabetoMorse[] = {
        ".-",   // A
        "-...", // B
        "-.-.", // C
        "-..",  // D
        ".",    // E
        "..-.", // F
        "--.",  // G
        "....", // H
        "..",   // I
        ".---", // J
        "-.-",  // K
        ".-..", // L
        "--",   // M
        "-.",   // N
        "---",  // O
        ".--.", // P
        "--.-", // Q
        ".-.",  // R
        "...",  // S
        "-",    // T
        "..-",  // U
        "...-", // V
        ".--",  // W
        "-..-", // X
        "-.--", // Y
        "--.."  // Z
    };

Morse::Morse(int pin) {
  pinLed = pin;
}

void Morse:: FunPunto(){

  digitalWrite(pinLed, HIGH);
  delay(100);
  digitalWrite(pinLed, LOW);
  delay(300);
  
}

void Morse:: FunLinea(){
  
  digitalWrite(pinLed, HIGH);
  delay(500);
  digitalWrite(pinLed, LOW);
  delay(300);
  
}

void Morse:: Inicio(){

pinMode(pinLed, OUTPUT);
  
}

void Morse:: Escribir(char Caracter){
  String Codigo = AlfabetoMorse[Caracter-65];

  for (int i=0; i<Codigo.length(); i++){
    if (Codigo.charAt(i)== '.'){
      
      FunPunto();
    
    }else{

      FunLinea();

    }
  }
  delay(50);
}