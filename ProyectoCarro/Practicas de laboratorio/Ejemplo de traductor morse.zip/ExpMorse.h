class Morse{

public:

  Morse(int pin);
  void Inicio();
  void Escribir(char Caracter);

private:
  int pinLed;
  void FunPunto();
  void FunLinea();

};