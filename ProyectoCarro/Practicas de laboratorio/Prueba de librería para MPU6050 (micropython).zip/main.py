from MPU6050 import mpu6050 
from utime import sleep

mpu = mpu6050()

while True:
    #print (mpu.LeerTemperatura())
    #sleep(0.5)

#   Aceleracion_X, Aceleracion_Y, Aceleracion_Z = mpu.leerAceleracionCadena()

#    print (f'Aceleración X: {Aceleracion_X:.02f}, Aceleración Y: {Aceleracion_Y:.02f}, Aceleración Z: {Aceleracion_Z:.02f}, ')
    
    print(mpu.leerGuinada())
    
    sleep(0.1)



