from machine import I2C, Pin
import time
import math

class mpu6050: 
    
    def __init__(self):

        self.i2c = I2C(freq=400000, scl=Pin(22), sda=Pin(21))
        self.i2c.writeto_mem(0x68, 0x6B, bytes([0]))
        self.dt = 0.01  # Intervalo de muestreo (ajustable según la tasa de lectura)
        self.alpha = 0.98  # Constante del filtro complementario
        self.yaw = 0  # Inicializar guiñada
        self.last_time = time.ticks_ms()

    def LeerRegistro(self, Direccion):
        Registro_PA = self.i2c.readfrom_mem(0x68, Direccion, 1) [0]
        Registro_PB = self.i2c.readfrom_mem(0x68, Direccion+1, 1) [0]

        Registro = (((Registro_PA << 8)|Registro_PB))

        if Registro > 32767:
            Registro = Registro - 65535
        
        return Registro

    def leerAceleracionCadena(self):
        
        Aceleracion_X = self.LeerRegistro(0x3B)/16834
        Aceleracion_Y = self.LeerRegistro(0x3D)/16834
        Aceleracion_Z = self.LeerRegistro(0x3F)/16834

        return(Aceleracion_X, Aceleracion_Y, Aceleracion_Z)

    def LeerTemperatura(self):
        
        Temperatura_PA = self.i2c.readfrom_mem(0x68, 0x41, 1) [0]
        Temperatura_PB = self.i2c.readfrom_mem(0x68, 0x42, 1) [0]

        TemperaturaSumada = (Temperatura_PA << 8) | Temperatura_PB

        TemperaturaTotal = TemperaturaSumada - 65535

        TemperaturaReal = (TemperaturaTotal/340) + 36.53

        return(TemperaturaReal)

    def LeerGiroscopio(self):
        Gx = self.LeerRegistro(0x43) / 131.0
        Gy = self.LeerRegistro(0x45) / 131.0
        Gz = self.LeerRegistro(0x47) / 131.0
        return (Gx, Gy, Gz)

    def leerGuinada(self):
        Gx, Gy, Gz = self.LeerGiroscopio()
        Ax, Ay, Az = self.leerAceleracionCadena()
        
        # Cálculo del ángulo basado en la aceleración
        yaw_acc = math.atan2(Ay, Ax) * (180 / math.pi)
        
        # Calcular delta tiempo
        current_time = time.ticks_ms()
        dt = (current_time - self.last_time) / 1000.0
        self.last_time = current_time
        
        # Filtro complementario
        self.yaw = self.alpha * (self.yaw + Gz * dt) + (1 - self.alpha) * yaw_acc
        
        return self.yaw
    

