from machine import Pin
from time import sleep

M1A = Pin(26, Pin.OUT)
M1B = Pin(25, Pin.OUT)

M2A = Pin(19, Pin.OUT)
M2B = Pin(18, Pin.OUT)

Sensfront = Pin(4, Pin.IN, Pin.PULL_UP)
Senslat = Pin(16, Pin.IN, Pin.PULL_UP)

def Adelante():

    M1A.value(0)
    M1B.value(1)

    M2A.value(0)
    M2B.value(1)

def Derecha():

    M1A.value(0)
    M1B.value(1)

    M2A.value(1)
    M2B.value(0)

def Izquierda():

    M1A.value(1)
    M1B.value(0)

    M2A.value(0)
    M2B.value(1)

def Atras():

    M1A.value(1)
    M1B.value(0)

    M2A.value(1)
    M2B.value(0)

def LeerSensorFrontal():
    return Sensfront.value()

def LeerSensorLateral():
    return Senslat.value()

Estado = "Adelante"

while True:

    #lógica de salida
    if Estado == "Adelante":
            Adelante()

    if Estado == "Derecha":
            Derecha()

    if Estado == "Izquierda":
            Izquierda()

    SensorFrontal = LeerSensorFrontal()
    SensorLateral = LeerSensorLateral()

    #lógica de estados

    if not SensorFrontal and SensorLateral:
        Estado = "Derecha"
    else:
        if not SensorLateral and not SensorFrontal:
            Estado = "Izquierda"
        else:
            Estado = "Adelante"

    sleep (0.5)
 