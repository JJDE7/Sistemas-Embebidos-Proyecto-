from morse import Morse

m1 = Morse(4)
m2 = Morse(2)

while True:

   m1.write('sos')
   m2.write('EEEEE')