from machine import Pin
from utime import sleep

morse = {
    'A': ".-",   'B': "-...", 'C': "-.-.", 'D': "-..",  'E': ".",  
    'F': "..-.", 'G': "--.",  'H': "....", 'I': "..",   'J': ".---",
    'K': "-.-",  'L': ".-..", 'M': "--",   'N': "-.",   'O': "---",
    'P': ".--.", 'Q': "--.-", 'R': ".-.",  'S': "...",  'T': "-",
    'U': "..-",  'V': "...-", 'W': ".--",  'X': "-..-", 'Y': "-.--",
    'Z': "--.."
}

class Morse:

    def __init__(self, pin):

        self.led = Pin(pin, Pin.OUT)


    def dot(self):

        self.led.on()
        sleep(0.1)
        self.led.off()
        sleep(0.3)

    def dash(self):

        self.led.on()
        sleep(0.3)
        self.led.off()
        sleep(0.5)

    def write(self, Mensaje):

        for c in Mensaje:

            code = morse[c.upper()]

            for i in code:
                if i == '.':
                    self.dot()
                else:
                    self.dash()
            sleep(0.5)