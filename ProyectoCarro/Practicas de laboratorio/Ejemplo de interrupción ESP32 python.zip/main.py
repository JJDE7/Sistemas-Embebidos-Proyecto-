from machine import Pin
from time import sleep

Led = Pin (4,Pin.OUT)
Boton = Pin (14, Pin.IN, Pin. PULL_UP)

Presionado = False

def Interrupcion(Argumento):
    global Presionado
    Presionado = True

Boton.irq(trigger=Pin.IRQ_FALLING, handler = Interrupcion)

while True:
    if not Boton.value():
        Led.on()
        sleep(1)
        Led.off() 
        Presionado = False